/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg3dexample;


import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.SAXException;

/**
 *
 * @author Ann
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Canvas canvas;
    private Scene scene;
    private canHandler handler;
    private TreeMap<String, Atom> atoms;
    private TreeMap<String, ArrayList<Atom>> molecule;
    private Drawer drawer;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        SAXParser parser = null;
        try {
            parser = factory.newSAXParser();
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        MolParser mparser = new MolParser();
        File f = new File("./build/classes/pkg3dexample/Molecule.xml");
        try {
            parser.parse(f, mparser);
        } catch (SAXException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        atoms = mparser.getAtoms();
        molecule = mparser.getMolecule();
        drawer = new Drawer(canvas, atoms, molecule);
        handler = new canHandler(drawer, atoms, molecule);
        // TODO
    }    
    public TreeMap<String, Atom> getAtoms() {
        return atoms;
    }

    public TreeMap<String, ArrayList<Atom>> getMolecule() {
        return molecule;
    }
    public void init(Scene sc){
        scene = sc;
        scene.setOnMouseDragged(handler);
        scene.setOnMouseClicked(handler);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.setFill(Color.BEIGE);
        gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        int i = 0;
        Random rand = new Random();
        for(Entry<String, Atom> e :atoms.entrySet()){
            double x = i*canvas.getWidth()/atoms.size()+25;
            double y =  rand.nextDouble()*(canvas.getHeight()-40)+20;
            e.getValue().setX(x);
            e.getValue().setY(y);
            drawer.drawAtom(e.getValue());
            i++;
        }
    }
}
