/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg3dexample;

import java.util.ArrayList;
import java.util.TreeMap;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 *
 * @author kazac
 */
public class Drawer {
    private Canvas canvas;
    private TreeMap<String, Atom> atoms;
    private TreeMap<String, ArrayList<Atom>> molecule;
    private GraphicsContext gc;
    public Drawer(Canvas c, TreeMap<String, Atom> at,TreeMap<String, ArrayList<Atom>> mol ){
        canvas = c;
        atoms = at;
        molecule = mol;
        gc = canvas.getGraphicsContext2D();
    }
    public void drawAtom(Atom a){
        int val = a.getValency();
        
        double x = a.getX();
        double y = a.getY();
        gc.setFill(Color.BLACK);
        for(int j = 0; j<val; j++){
            double xp[]= new double[4];
            double yp[]= new double[4];
            System.out.println(j*(360.0/val));
            System.out.println("cos: "+Math.cos(Math.toRadians(j*(360.0/val))));
            System.out.println("sin: "+Math.sin(Math.toRadians(j*(360.0/val))));
            xp[0]=x;
            yp[0]=y-2;
            xp[1]=xp[0]+1*Math.sin(Math.toRadians(j*(360.0/val)));
            yp[1]=yp[0]+1*Math.cos(Math.toRadians(j*(360.0/val)));
            xp[2]=xp[1]+20*Math.cos(Math.toRadians(j*(360.0/val)));
            yp[2]=yp[1]+20*Math.sin(Math.toRadians(j*(360.0/val)));
            xp[3]=xp[0]+20*Math.cos(Math.toRadians(j*(360.0/val)));
            yp[3]=yp[0]+20*Math.sin(Math.toRadians(j*(360.0/val)));
            System.out.println("x;y "+x+";"+y);
            System.out.println("x;y 0 "+xp[0]+";"+yp[0]);
            System.out.println("x;y 1 "+xp[1]+";"+yp[1]);
            System.out.println("x;y 2 "+xp[2]+";"+yp[2]);
            System.out.println("x;y 3 "+xp[3]+";"+yp[3]);
            gc.fillPolygon(xp, yp, 4);
        }
        gc.setFill(Color.BEIGE);
        gc.fillOval(x-10, y-10, 20, 20);
        gc.strokeText(a.getType(),x-2 ,y+2);

    }
    
    public void drawSelected(Atom a){
        drawAtom(a);
        gc.setLineDashes(5.0);
        gc.setStroke(Color.RED);
        gc.strokeRect(a.getX()-20,a.getY()-20, 40, 40);
        gc.setFill(Color.BEIGE);
        gc.setLineDashes(0.0);
        gc.setStroke(Color.BLACK);
    }
    
    public void drawUnselected(Atom a){
        gc.fillRect(a.getX()-22, a.getY()-22, 44,44);
        drawAtom(a);
    }
    public void erase(Atom a){
        gc.fillRect(a.getX()-22, a.getY()-22, 44,44);
    }
}
